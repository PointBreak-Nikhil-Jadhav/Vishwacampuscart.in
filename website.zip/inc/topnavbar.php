<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="img_assets/logo.png" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
      <?php echo $APP_NAME ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>


        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Category
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <!-- <li><a class="dropdown-item" href="">Laptop / Accessories</a></li>
            <li><a class="dropdown-item" href="#">Books, Sports & Hobbies</a></li>
            <li><a class="dropdown-item" href="#">Bikes / Cars</a></li>
            <li><a class="dropdown-item" href="#">Electronics and appliances</a></li>
            <li><a class="dropdown-item" href="#">Mobile</a></li>
            <li><a class="dropdown-item" href="#">Services</a></li>
            <li><a class="dropdown-item" href="#">Furniture</a></li> -->

            <?php
            $q = 'SELECT id, cat_name FROM category';
            $result = $conn->query($q);
            $i = 1;
            if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) :
            ?>
                <li><a class="dropdown-item" href="index.php?page=list&cat_id=<?php echo $row['id'] ?>"><?php echo $row['cat_name']; ?></a></li>
            <?php
                $i++;
              endwhile;
            } ?>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li><a class="dropdown-item" href="index.php?page=list">All Categories</a></li>
          </ul>
        </li>




        <li class="nav-item">
          <button class="nav-link" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions">More</button>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php?page=my_ac">My Account </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php?page=help">Help</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php?page=about">About</a>
        </li>
      </ul>
      <div class="d-flex">
        <input id="search-ip" class="form-control me-2 shadow-sm" type="search" placeholder="Search" aria-label="Search" value="<?php echo isset($_GET['fsearch']) ? $_GET['fsearch'] : '' ?>">
        <button id="search" class="btn btn-outline-success shadow-sm" type="submit">Search</button>
      </div>
      <script>
        $('#search').click(() => {
          window.location.replace(
            "index.php?page=list&fsearch=" + $('#search-ip').val()
          );
        });
      </script>
      <ul class="navbar-nav mb-2 mb-lg-0 ms-2">
        <li class="nav-itemrounded-1">
          <?php
          if (isset($_SESSION['user'])) {
            echo '
              <a class="btn bg-primary shadow-sm btn-outline-success text-light" href="logout.php">
                Logout
              </a>
            ';
          } else {
            echo '<a class="btn bg-primary shadow-sm btn-outline-success text-light" href="login.php">
                  Login
                  </a>';
          }
          ?>

        </li>
      </ul>
    </div>
  </div>
</nav>



<div class="offcanvas offcanvas-start" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions" aria-labelledby="offcanvasWithBothOptionsLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasWithBothOptionsLabel"><?php echo $APP_NAME; ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <p><a href="index.php?page=sell" class="btn">Sell / Post Ad</a></p>

    <?php
    if (isset($_SESSION['user'])) {
    ?><p><a href="index.php?page=my_product" class="btn">My Products / My Ads</a></p><?php
                                                                                    }
                                                                                      ?>

    <?php
    if (!isset($_SESSION['user'])) {
    ?><p><a href="index.php?page=create_ac" class="btn">Create Account Here</a></p><?php
                                                                                  }
                                                                                    ?>

  </div>
</div>