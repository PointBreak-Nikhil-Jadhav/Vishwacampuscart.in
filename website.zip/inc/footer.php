<div class="container mt-5">
  <hr>
</div>

<footer class="container-fluid bg-dark text-light text-center py-3">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h5>Contact Details</h5>
        <p>Email: campuscartvit@gmail.com</p>
        <p>Phone: +91 9322572308</p>
      </div>
      <div class="col-md-6">
        <h5>college Address</h5>
        <p>Vishwakarma institute of technology</p>
        <p>Bibwewadi katraj pune,411037 </p>
      </div>
    </div>
    <div class="row mt-3">
      <div class="col-md-12">
        <p>Developed and Designed by <a href="" class="text-white text-decoration-none">DIV:-M M10 group</a></p>
      </div>
    </div>
  </div>
</footer>

<script src="bootstrap/js/popper.min.js"></script>
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="bootstrap/js/bootstrap1.bundle.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/slim.min.js"></script>
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="bootstrap/js/bootstrap1.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>