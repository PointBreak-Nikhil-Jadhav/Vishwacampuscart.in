<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> <?php echo $APP_NAME ?></title>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="bootstrap/css/font.all.min.css" rel="stylesheet">

  <!-- <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="bootstrap/js/bootstrap1.bundle.min.js"></script> -->
  <!-- above scripts added in footer -->
  
  <!-- <script src="bootstrap/js/popper.min.js"></script>

  <script src="bootstrap/js/bootstrap.min.js"></script>
  <script src="bootstrap/js/slim.min.js"></script> -->
</head>

<body>